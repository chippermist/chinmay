package AbstractShapes.library;

public class DColor {

	public int r;
	public int g;
	public int b;
	public int a;
	 
	 DColor(int r,int g, int b){
	    this.r = r;
	    this.g = g;
	    this.b = b;
	    this.a = 255;
	 }
	 
	 DColor(int r,int g, int b, int a){
		    this.r = r;
		    this.g = g;
		    this.b = b;
		    this.a = a;
		 }
	
}
