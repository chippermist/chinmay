package AbstractShapes.library;


import processing.core.*;

/**
 * This is a template class and can be used to start a new processing Library.
 * Make sure you rename this class as well as the name of the example package 'template' 
 * to your own Library naming convention.
 * 
 * (the tag example followed by the name of an example included in folder 'examples' will
 * automatically include the example in the javadoc.)
 *
 * @example Hello 
 */

public class AbstractShapes {
	
	// myParent is a reference to the parent sketch
	PApplet myParent;
	DColor fillColor;
	DColor strokeColor;
	float strokeWeight;
	boolean noFill = true;
	boolean noStroke = false;
	
	public final static String VERSION = "1.0.0";
	

	/**
	 * a Constructor, usually called in the setup() method in your sketch to
	 * initialize and start the Library.
	 * 
	 * @example Hello
	 * @param theParent
	 */
	public AbstractShapes(PApplet theParent) {
		myParent = theParent;
		strokeColor = new DColor(0,0,0);
		fillColor = new DColor(255,255,255);
		strokeWeight = 1;
		welcome();
	}
	
	
	private void welcome() {
		System.out.println("Your Library 1.0.0 by Your Name http://yoururl.com");
	}
	
	
	public String printHelloWorld() {
		return "Hello, World!";
	}
	/**
	 * return the version of the Library.
	 * 
	 * @return String 
	 */
	public static String version() {
		return VERSION;
	}
	
	
	public void fill(int r, int g, int b){
	      fillColor = new DColor(r,g,b);
	      noFill = false;
	    }
	
	public void fill(int r, int g, int b, int a){
	      fillColor = new DColor(r,g,b,a);
	      noFill = false;
	    }
	
	public void stroke(int r, int g, int b){
	      strokeColor = new DColor(r,g,b);
	      noStroke = false;
	    }
	public void stroke(int r, int g, int b, int a){
	      strokeColor = new DColor(r,g,b,a);
	      noStroke = false;
	    }
	
	public void noStroke(){
	     noStroke = true;
	    }
	
	public void strokeWeight(float weight){
	    this.strokeWeight = weight;
	    }
	
	
	public void noFill(){
	     noFill = true;
	    }


}

