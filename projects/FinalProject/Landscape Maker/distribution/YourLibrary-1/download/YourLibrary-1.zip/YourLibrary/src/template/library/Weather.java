package template.library;

import processing.core.*;

public class Weather extends LandscapeMaker {
	PApplet p;
	
	public Weather(PApplet theParent) {
		super(theParent);
		// TODO Auto-generated constructor stub
		p = theParent;
	}

}
