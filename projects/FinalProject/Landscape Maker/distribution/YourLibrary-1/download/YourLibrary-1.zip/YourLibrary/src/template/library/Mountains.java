package template.library;

import processing.core.*;

public class Mountains extends LandscapeMaker {
	PApplet p;
	
	public Mountains(PApplet theParent) {
		super(theParent);
		// TODO Auto-generated constructor stub
		p = theParent;
	}
	
	public void mountains(String type) {
		
	}
	
	@SuppressWarnings("static-access")
	void mountains(color closerColor, color furtherColor, color mistColor)
	{
	  //FIND THE REFERENCE Y OF EACH MOUNTAIN:
	  float y0 = p.width - 500;  //fist reference y
	  int i0 = 30;  //initial interval
	  
	  float[] cy = new float[10]; //initialize the reference y array
	  for (int j = 0; j < 10; j++)
	  {
	    cy[9-j] = y0;
	    y0 -= i0 / p.pow((float) 1.2, j);
	  }
	  
	  
	  //DRAW THE MOUNTAINS/
	  float dx = 0;
	  
	  for (int j = 1; j <  10; j++)
	  {               
	    float a = p.random(-p.width/2, p.width/2);  //random discrepancy between the sin waves
	    float b = p.random(-p.width/2, p.width/2);  //random discrepancy between the sin waves  
	    float c = p.random(2, 4);  //random amplitude for the second sin wave
	    float d = p.random(40, 50);  //noise function amplitude
	    float e = p.random(-p.width/2, p.width/2);  //adds a discrepancy between the noise of each mountain
	      
	    for (int x = 0; x < p.width; x ++)
	    {          
	      float y = cy[j]; //y = reference y 
	      y += 10*j*p.sin(2*dx/j + a);  //first sin wave oscillates according to j (the closer the mountain, the bigger the amplitude and smaller the frequency)        
	      y += c*j*p.sin(5*dx/j + b);   //second sin wave has a random medium amplitude (affects more the further mountains) and bigger frequenc  
	      y += d*j*p.noise((float) (1.2*dx/j +e));  //first noise function adds randomness to the mountains, amplitude depends on a random number and increases with j, frequency decrases with j
	      y += 1.7*j*p.noise(10*dx);  //second noise function simulates the canopy, it has high frequency and small amplitude depending on j so it is smoother on the further mountains
	      
	      p.strokeWeight(2);  //mountains look smoother with stroke weight of 2
	      p.stroke(lerpColor(furtherColor, closerColor, j/9));
	      p.line(x, y, x, p.height); 
	      
	      dx += 0.02;
	    }
	    
	   
	    //ADD MIST 
	    for (int i =  p.height; i > cy[j]; i -= 3)
	    {
	      float alfa = p.map(i, cy[j], p.height, 0, 360/(j+1));  //alfa is begins bigger for the further mountains      
	      p.strokeWeight(3);  //interval of 3 for faster rendering
	      p.stroke(mistColor, alfa);     
	      p.line(0, i, p.width, i);
	    } 
	  }
	}
	
}
