package template.library;

import processing.core.*;

public class Trees extends LandscapeMaker {
	PApplet p;
	
	public Trees(PApplet theParent) {
		super(theParent);
		// TODO Auto-generated constructor stub
		p = theParent;
	}

}
